# project-landing-page
<img height=auto width=100px src="https://cdn.statically.io/gh/TheOdinProject/curriculum/81a5d553f4073e593d23a6ab00d50eef8620796d/foundations/html_css/project/imgs/01.png"/>
Final project of TOP foundations CSS part : a landing page utilizing flexbox.
